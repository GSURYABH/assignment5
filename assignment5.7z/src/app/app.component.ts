import { Component } from '@angular/core';

import {FormGroup,FormControl,Validators} from '@angular/forms'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'assignment5';
  id:number;
  name:string;
  cost:number;
  isonline:string;
  iscategory:string;
  isavaliable:string;
  myform = new FormGroup(
    {
        productid : new FormControl("Enterproductid" ,Validators.required ),
        productname : new FormControl("Enterproductname" ,Validators.required ),
        productcost : new FormControl("Enterproductcost" ,Validators.required )

    }
  )
  online(an){
    this.isonline=an;
  }
  category(cat){
    this.iscategory=cat;
  }
  avaliable(ava){
    this.isavaliable=ava;
  }
  onSubmit(){
    console.log(this.myform);

    }
  
}
